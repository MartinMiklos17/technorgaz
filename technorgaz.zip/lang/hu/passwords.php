<?php

return [
    'reset' => 'A jelszavad visszaállításra került!',
    'sent' => 'A jelszó-visszaállító linket elküldtük az e-mail címedre!',
    'throttled' => 'Kérjük, várj egy kicsit, mielőtt újra próbálkozol.',
    'token' => 'Ez a jelszó-visszaállító token érvénytelen.',
    'user' => 'Nem található felhasználó ezzel az e-mail címmel.',
];
