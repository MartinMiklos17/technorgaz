<?php
namespace App\Forms\Schemas;

use Filament\Forms;
use Filament\Forms\Components\Section;
use App\Enums\AccountType;
class CompanyFormSchema
{
    public static function get(): array
    {
        return [

        ];
    }
}
