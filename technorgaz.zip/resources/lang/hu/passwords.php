<?php

return [
    'reset' => 'A jelszavad sikeresen visszaállítva!',
    'sent' => 'Emailben elküldtük a jelszó-visszaállító linket!',
    'throttled' => 'Kérjük, várj mielőtt újra próbálkozol.',
    'token' => 'Ez a jelszó visszaállító token érvénytelen.',
    'user' => 'Nem találunk felhasználót ilyen e-mail címmel.',
];
