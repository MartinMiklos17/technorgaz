<?php

return [
    'reset_password_subject' => 'Jelszó visszaállítása',
    'reset_password_greeting' => 'Helló!',
    'reset_password_notification' => 'Ezt az e-mailt azért kaptad, mert jelszó-visszaállítást kértek a fiókodhoz.',
    'reset_password_action' => 'Jelszó visszaállítása',
    'reset_password_expire' => 'Ez a jelszó-visszaállítási link :count perc múlva lejár.',
    'reset_password_ignore' => 'Ha nem te kérted, nincs további teendőd.',
];
